# Changelog

## 0.0.1 (2023-02-05)

#### Fixes

* correct user.solve_recaptcha_v3 signature
* fix bug with getting root domain


## v0.0.0 (2023-01-29)
